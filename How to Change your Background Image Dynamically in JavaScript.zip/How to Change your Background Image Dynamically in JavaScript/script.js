function changeBackground(image){
	document.getElementById('display').innerHTML="";
	document.getElementById('display').style.backgroundImage="url('"+image.src+"')";
	document.getElementById('display').style.backgroundSize="cover";
	document.getElementById('display').style.backgroundPosition="center center";
}